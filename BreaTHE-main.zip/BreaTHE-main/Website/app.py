import numpy as np
import tensorflow as tf
import librosa
from flask import Flask, render_template, request

app = Flask(__name__)
model = tf.keras.models.load_model('./models/lstm_model.h5')


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    audio = request.files['audio']
    classes = ["COPD", "Bronchiolitis", "Pneumonia", "URTI", "Healthy"]

    y, sr = librosa.load(audio)
    mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=50)
    features = np.mean(mfccs, axis=1)
    features = np.expand_dims(features, axis=0)
    features = np.expand_dims(features, axis=2)

    test_pred = model.predict(features)
    class_pred = classes[np.argmax(test_pred)]
    confidence = test_pred.max()

    output = [class_pred, confidence]
    return render_template('index.html', prediction_text="The Disease is {}".format(output))


if __name__ == '__main__':
    app.run(debug=True)
