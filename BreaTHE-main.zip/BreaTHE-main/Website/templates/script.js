const form = document.querySelector("form");
form.addEventListener("submit", async (event) => {
	event.preventDefault();
	const formData = new FormData();
	const audioFile = event.target.elements.audioFile.files[0];
	formData.append("audioFile", audioFile);
	const response = await fetch("http://127.0.0.1:5000/predict", {
		method: "POST",
		body: formData,
	});
	const result = await response.json();
	// do something with the result
});
